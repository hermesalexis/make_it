A Pen created at CodePen.io. You can find this one at http://codepen.io/hermesalexis1/pen/WpRrGd.

 Most of the time these slide in or fade in - just playing with other instantiation animations.

All animations are class-driven, and are animating the exact same HTML elements.